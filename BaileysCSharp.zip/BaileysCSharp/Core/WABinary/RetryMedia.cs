﻿namespace BaileysCSharp.Core.WABinary
{
    public class RetryMedia
    {
        public byte[] IV { get; set; }
        public byte[] CipherText { get; set; }
    }

}