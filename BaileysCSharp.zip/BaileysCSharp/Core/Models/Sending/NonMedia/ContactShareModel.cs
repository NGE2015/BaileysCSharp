﻿namespace BaileysCSharp.Core.Models.Sending.NonMedia
{
    public class ContactShareModel
    {
        public string FullName { get; set; }
        public string Organization { get; set; }
        public string ContactNumber { get; set; }
    }
}
