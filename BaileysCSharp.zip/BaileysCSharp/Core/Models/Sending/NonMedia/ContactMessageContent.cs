﻿namespace BaileysCSharp.Core.Models.Sending.NonMedia
{
    public class ContactMessageContent : AnyMessageContent
    {
        public ContactShareModel Contact { get; set; }
    }
}
