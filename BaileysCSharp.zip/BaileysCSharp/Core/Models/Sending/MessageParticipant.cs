﻿namespace BaileysCSharp.Core.Models.Sending
{
    public class MessageParticipant
    {
        public string Jid { get; set; }
        public ulong Count { get; set; }
    }
}
