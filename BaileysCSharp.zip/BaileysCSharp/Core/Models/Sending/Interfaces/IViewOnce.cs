﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IViewOnce
    {
        bool ViewOnce { get; set; }
    }
}
