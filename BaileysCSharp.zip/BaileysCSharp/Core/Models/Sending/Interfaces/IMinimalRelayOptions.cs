﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IMinimalRelayOptions
    {
        public string MessageID { get; set; }
    }
}
