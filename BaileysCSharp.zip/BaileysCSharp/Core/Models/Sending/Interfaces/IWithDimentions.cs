﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IWithDimentions
    {
        public uint Width { get; set; }
        public uint Height { get; set; }
    }
}
