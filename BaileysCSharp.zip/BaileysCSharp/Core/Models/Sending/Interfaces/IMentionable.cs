﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IMentionable
    {
        string[] Mentions { get; set; }
    }
}
