﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IMessageContentGenerationOptions : IMediaGenerationOptions
    {

    }
}
