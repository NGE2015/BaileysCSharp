﻿namespace BaileysCSharp.Core.Models.Sending.Interfaces
{
    public interface IMessageGenerationOptions : IMessageGenerationOptionsFromContent, IMessageContentGenerationOptions
    {

    }
}
