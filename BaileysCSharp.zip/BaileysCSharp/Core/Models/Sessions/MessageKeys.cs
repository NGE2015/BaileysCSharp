﻿namespace BaileysCSharp.Core.Models.Sessions
{
    public class MessageKeys
    {
    }
}
