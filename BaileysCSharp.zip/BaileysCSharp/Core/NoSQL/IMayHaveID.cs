﻿namespace BaileysCSharp.Core.NoSQL
{
    public interface IMayHaveID
    {
        string GetID();
    }
}
