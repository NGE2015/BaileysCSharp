﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaileysCSharp.Core.Types;
public class SyncState
{

    public bool? IsNewLogin { get; set; }
    public string? Msg { get; set; }
    public uint Prograss { get; set; }

}
