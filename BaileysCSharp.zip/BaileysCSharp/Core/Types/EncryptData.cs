﻿namespace BaileysCSharp.Core.Types
{
    public class EncryptData
    {
        public int Type { get; set; }
        public byte[] Data { get; set; }
        public ulong RegistrationId { get; set; }
    }
}
