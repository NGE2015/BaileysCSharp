﻿namespace BaileysCSharp.Core.Models
{
    public enum WAConnectionState
    {
        Open = 1,
        Connecting = 2,
        Close = 3,
        Closed = 4
    }
}
