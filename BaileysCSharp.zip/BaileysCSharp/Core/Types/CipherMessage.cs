﻿namespace BaileysCSharp.Core.Types
{
    public record CipherMessage(string Type, byte[] CipherText);
}
